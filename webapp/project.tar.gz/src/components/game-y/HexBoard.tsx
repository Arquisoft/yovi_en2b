import { useState, useMemo, useCallback } from 'react'
import type { BoardCell, BoardSize, PlayerColor, Move } from '@/types'
import { HexCell } from './HexCell'
import { getHexPosition, getBoardDimensions, getCellSides } from '@/utils/gameY'

interface HexBoardProps {
  board: BoardCell[][]
  size: BoardSize
  currentTurn: PlayerColor
  lastMove: Move | null
  isInteractive: boolean
  onCellClick: (row: number, col: number) => void
}

/**
 * The triangular hexagonal board for Game Y
 * Renders a proper triangular arrangement of hexagons
 */
export function HexBoard({
  board,
  size,
  lastMove,
  isInteractive,
  onCellClick,
}: HexBoardProps) {
  const [hoveredCell, setHoveredCell] = useState<{ row: number; col: number } | null>(null)
  
  // Calculate hex size based on board size and viewport
  // Larger boards need smaller hexes to fit
  const hexSize = useMemo(() => {
    // Base size adjusted for board size
    const baseSize = Math.max(20, Math.min(40, 320 / size))
    return baseSize
  }, [size])
  
  // Get board dimensions for SVG viewBox
  const dimensions = useMemo(
    () => getBoardDimensions(size, hexSize),
    [size, hexSize]
  )
  
  // Determine edge type for each cell
  const getEdgeType = useCallback(
    (row: number, col: number): 'left' | 'right' | 'bottom' | 'corner' | 'internal' => {
      const sides = getCellSides(row, col, size)
      
      if (sides.length >= 2) {
        return 'corner'
      }
      if (sides.includes(0)) {
        return 'left'
      }
      if (sides.includes(1)) {
        return 'right'
      }
      if (sides.includes(2)) {
        return 'bottom'
      }
      return 'internal'
    },
    [size]
  )
  
  // Handle cell click
  const handleCellClick = useCallback(
    (row: number, col: number) => {
      if (!isInteractive) return
      const cell = board[row]?.[col]
      if (cell?.owner === null) {
        onCellClick(row, col)
      }
    },
    [board, isInteractive, onCellClick]
  )
  
  // Check if a cell is the last move
  const isLastMove = useCallback(
    (row: number, col: number): boolean => {
      return lastMove?.row === row && lastMove?.col === col
    },
    [lastMove]
  )
  
  // Render all cells
  const cells = useMemo(() => {
    const result: JSX.Element[] = []
    
    for (let row = 0; row < size; row++) {
      for (let col = 0; col <= row; col++) {
        const cell = board[row]?.[col]
        if (!cell) continue
        
        const { x, y } = getHexPosition(row, col, hexSize)
        const edgeType = getEdgeType(row, col)
        const isHovered = hoveredCell?.row === row && hoveredCell?.col === col
        const isClickable = isInteractive && cell.owner === null
        
        result.push(
          <HexCell
            key={`${row}-${col}`}
            row={row}
            col={col}
            x={x}
            y={y}
            size={hexSize}
            owner={cell.owner}
            isLastMove={isLastMove(row, col)}
            isHovered={isHovered}
            isClickable={isClickable}
            onClick={() => handleCellClick(row, col)}
            onMouseEnter={() => setHoveredCell({ row, col })}
            onMouseLeave={() => setHoveredCell(null)}
            edgeType={edgeType}
          />
        )
      }
    }
    
    return result
  }, [board, size, hexSize, hoveredCell, isInteractive, getEdgeType, handleCellClick, isLastMove])
  
  return (
    <div className="w-full flex items-center justify-center p-4">
      <svg
        viewBox={`0 0 ${dimensions.width} ${dimensions.height}`}
        className="w-full h-auto max-h-[70vh]"
        style={{ maxWidth: `${dimensions.width}px` }}
        aria-label="Game Y Board"
        role="grid"
      >
        {/* Board edge labels */}
        <defs>
          <linearGradient id="leftEdge" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="hsl(var(--player1))" stopOpacity="0.3" />
            <stop offset="100%" stopColor="hsl(var(--player1))" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="rightEdge" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="hsl(var(--player2))" stopOpacity="0.3" />
            <stop offset="100%" stopColor="hsl(var(--player2))" stopOpacity="0" />
          </linearGradient>
        </defs>
        
        {/* Cells */}
        {cells}
        
        {/* Side labels */}
        <text
          x={hexSize / 2}
          y={dimensions.height / 2}
          fill="hsl(var(--player1))"
          fontSize={hexSize * 0.5}
          fontWeight="bold"
          textAnchor="middle"
          className="select-none pointer-events-none"
          transform={`rotate(-60, ${hexSize / 2}, ${dimensions.height / 2})`}
        >
          P1
        </text>
        <text
          x={dimensions.width - hexSize / 2}
          y={dimensions.height / 2}
          fill="hsl(var(--player2))"
          fontSize={hexSize * 0.5}
          fontWeight="bold"
          textAnchor="middle"
          className="select-none pointer-events-none"
          transform={`rotate(60, ${dimensions.width - hexSize / 2}, ${dimensions.height / 2})`}
        >
          P2
        </text>
      </svg>
    </div>
  )
}
