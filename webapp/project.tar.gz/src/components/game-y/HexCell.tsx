import { memo } from 'react'
import type { PlayerColor } from '@/types'
import { cn } from '@/utils'
import { getHexPath } from '@/utils/gameY'

interface HexCellProps {
  row: number
  col: number
  x: number
  y: number
  size: number
  owner: PlayerColor | null
  isLastMove: boolean
  isHovered: boolean
  isClickable: boolean
  onClick: () => void
  onMouseEnter: () => void
  onMouseLeave: () => void
  edgeType: 'left' | 'right' | 'bottom' | 'corner' | 'internal'
}

/**
 * A single hexagonal cell on the Game Y board
 * Renders as an SVG path positioned absolutely
 */
export const HexCell = memo(function HexCell({
  x,
  y,
  size,
  owner,
  isLastMove,
  isHovered,
  isClickable,
  onClick,
  onMouseEnter,
  onMouseLeave,
  edgeType,
}: HexCellProps) {
  const hexPath = getHexPath(size * 0.95)
  
  // Determine fill color based on state
  const getFillColor = (): string => {
    if (owner === 'player1') {
      return 'hsl(var(--player1))'
    }
    if (owner === 'player2') {
      return 'hsl(var(--player2))'
    }
    if (isHovered && isClickable) {
      return 'hsl(var(--accent))'
    }
    return 'hsl(var(--card))'
  }
  
  // Determine stroke color based on edge type
  const getStrokeColor = (): string => {
    switch (edgeType) {
      case 'left':
        return 'hsl(var(--player1) / 0.6)'
      case 'right':
        return 'hsl(var(--player2) / 0.6)'
      case 'bottom':
        return 'hsl(var(--muted-foreground) / 0.6)'
      case 'corner':
        return 'hsl(var(--ring))'
      default:
        return 'hsl(var(--border))'
    }
  }

  return (
    <g
      transform={`translate(${x}, ${y})`}
      onClick={isClickable ? onClick : undefined}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      className={cn(
        'transition-all duration-150',
        isClickable && 'cursor-pointer'
      )}
      role={isClickable ? 'button' : undefined}
      tabIndex={isClickable ? 0 : undefined}
      aria-label={`Cell at position, ${owner ? `occupied by ${owner}` : 'empty'}`}
      onKeyDown={(e) => {
        if (isClickable && (e.key === 'Enter' || e.key === ' ')) {
          onClick()
        }
      }}
    >
      {/* Cell background */}
      <path
        d={hexPath}
        fill={getFillColor()}
        stroke={getStrokeColor()}
        strokeWidth={edgeType === 'internal' ? 1 : 2}
        className="transition-colors duration-150"
      />
      
      {/* Last move indicator */}
      {isLastMove && (
        <circle
          r={size * 0.15}
          fill="none"
          stroke="hsl(var(--foreground))"
          strokeWidth={2}
          className="animate-pulse"
        />
      )}
      
      {/* Hover indicator for empty cells */}
      {isHovered && isClickable && !owner && (
        <circle
          r={size * 0.3}
          fill="hsl(var(--muted-foreground) / 0.3)"
          className="pointer-events-none"
        />
      )}
    </g>
  )
})
