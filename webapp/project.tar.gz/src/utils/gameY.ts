import type { BoardCell, BoardSize, PlayerColor, Move } from '@/types'

/**
 * Create an empty triangular board for Game Y
 * Row 0 has 1 cell, Row 1 has 2 cells, etc.
 */
export function createEmptyBoard(size: BoardSize): BoardCell[][] {
  const board: BoardCell[][] = []
  for (let row = 0; row < size; row++) {
    const rowCells: BoardCell[] = []
    for (let col = 0; col <= row; col++) {
      rowCells.push({ row, col, owner: null })
    }
    board.push(rowCells)
  }
  return board
}

/**
 * Get the total number of cells on a triangular board
 */
export function getTotalCells(size: BoardSize): number {
  return (size * (size + 1)) / 2
}

/**
 * Get all valid neighbors for a hex cell on a triangular board
 * Hex adjacency: up to 6 neighbors
 */
export function getNeighbors(
  row: number,
  col: number,
  size: BoardSize
): { row: number; col: number }[] {
  const neighbors: { row: number; col: number }[] = []
  
  // Possible neighbor offsets for hex cells on triangular grid
  const offsets = [
    [-1, -1], // upper-left
    [-1, 0],  // upper-right
    [0, -1],  // left
    [0, 1],   // right
    [1, 0],   // lower-left
    [1, 1],   // lower-right
  ]

  for (const [dr, dc] of offsets) {
    const newRow = row + dr
    const newCol = col + dc
    
    // Check bounds for triangular board
    if (newRow >= 0 && newRow < size && newCol >= 0 && newCol <= newRow) {
      neighbors.push({ row: newRow, col: newCol })
    }
  }

  return neighbors
}

/**
 * Identify which side(s) a cell belongs to
 * Side 0: Left edge (col === 0)
 * Side 1: Right edge (col === row)
 * Side 2: Bottom edge (row === size - 1)
 * Corners belong to both adjacent sides
 */
export function getCellSides(
  row: number,
  col: number,
  size: BoardSize
): number[] {
  const sides: number[] = []
  
  // Left edge
  if (col === 0) {
    sides.push(0)
  }
  
  // Right edge
  if (col === row) {
    sides.push(1)
  }
  
  // Bottom edge
  if (row === size - 1) {
    sides.push(2)
  }
  
  return sides
}

/**
 * Check if a player has won by connecting all three sides
 * Uses flood fill / BFS to find connected components
 */
export function checkWinner(
  board: BoardCell[][],
  size: BoardSize
): PlayerColor | null {
  const players: PlayerColor[] = ['player1', 'player2']
  
  for (const player of players) {
    if (hasConnectedAllSides(board, size, player)) {
      return player
    }
  }
  
  return null
}

/**
 * Check if a specific player has connected all three sides
 */
function hasConnectedAllSides(
  board: BoardCell[][],
  size: BoardSize,
  player: PlayerColor
): boolean {
  // Find all cells belonging to this player on Side 0 (left edge)
  const startCells: { row: number; col: number }[] = []
  for (let row = 0; row < size; row++) {
    if (board[row][0]?.owner === player) {
      startCells.push({ row, col: 0 })
    }
  }
  
  if (startCells.length === 0) return false
  
  // BFS from all starting cells
  const visited = new Set<string>()
  const queue = [...startCells]
  const sidesReached = new Set<number>()
  
  for (const cell of startCells) {
    visited.add(`${cell.row},${cell.col}`)
    getCellSides(cell.row, cell.col, size).forEach((s) => sidesReached.add(s))
  }
  
  while (queue.length > 0) {
    const current = queue.shift()!
    const neighbors = getNeighbors(current.row, current.col, size)
    
    for (const neighbor of neighbors) {
      const key = `${neighbor.row},${neighbor.col}`
      if (visited.has(key)) continue
      
      const cell = board[neighbor.row]?.[neighbor.col]
      if (cell?.owner !== player) continue
      
      visited.add(key)
      queue.push(neighbor)
      
      getCellSides(neighbor.row, neighbor.col, size).forEach((s) => sidesReached.add(s))
      
      // Check if all three sides are reached
      if (sidesReached.has(0) && sidesReached.has(1) && sidesReached.has(2)) {
        return true
      }
    }
  }
  
  return sidesReached.has(0) && sidesReached.has(1) && sidesReached.has(2)
}

/**
 * Apply a move to the board (immutable)
 */
export function applyMove(
  board: BoardCell[][],
  move: Move
): BoardCell[][] {
  return board.map((row, rowIndex) =>
    row.map((cell, colIndex) =>
      rowIndex === move.row && colIndex === move.col
        ? { ...cell, owner: move.player }
        : cell
    )
  )
}

/**
 * Check if a move is valid
 */
export function isValidMove(
  board: BoardCell[][],
  row: number,
  col: number
): boolean {
  const cell = board[row]?.[col]
  return cell !== undefined && cell.owner === null
}

/**
 * Get the opposite player
 */
export function getOppositePlayer(player: PlayerColor): PlayerColor {
  return player === 'player1' ? 'player2' : 'player1'
}

/**
 * Calculate hex cell position for SVG rendering
 * Returns center point of the hexagon
 */
export function getHexPosition(
  row: number,
  col: number,
  hexSize: number
): { x: number; y: number } {
  // For a triangular arrangement of hexagons (pointy-top)
  const hexWidth = hexSize * Math.sqrt(3)
  const hexHeight = hexSize * 2
  const verticalSpacing = hexHeight * 0.75
  
  // Offset for triangular arrangement
  const rowOffset = ((row) * hexWidth) / 2
  
  const x = rowOffset + col * hexWidth + hexWidth / 2
  const y = row * verticalSpacing + hexSize
  
  return { x, y }
}

/**
 * Generate SVG path for a pointy-top hexagon
 */
export function getHexPath(size: number): string {
  const points: string[] = []
  for (let i = 0; i < 6; i++) {
    const angleDeg = 60 * i - 30
    const angleRad = (Math.PI / 180) * angleDeg
    const x = size * Math.cos(angleRad)
    const y = size * Math.sin(angleRad)
    points.push(`${x.toFixed(2)},${y.toFixed(2)}`)
  }
  return `M ${points.join(' L ')} Z`
}

/**
 * Calculate board dimensions for SVG viewport
 */
export function getBoardDimensions(
  size: BoardSize,
  hexSize: number
): { width: number; height: number } {
  const hexWidth = hexSize * Math.sqrt(3)
  const hexHeight = hexSize * 2
  const verticalSpacing = hexHeight * 0.75
  
  // Width is the bottom row width
  const width = (size - 1) * hexWidth / 2 + size * hexWidth + hexWidth / 2
  const height = (size - 1) * verticalSpacing + hexHeight
  
  return { 
    width: width + hexSize, 
    height: height + hexSize / 2 
  }
}
