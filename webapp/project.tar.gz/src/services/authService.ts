import type { User, AuthSession, LoginCredentials, RegisterCredentials } from '@/types'

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api'

/**
 * Authentication service using real Users API
 */
class AuthService {
  private baseUrl: string

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`
    
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    })

    const data = await response.json()

    if (!response.ok) {
      throw new Error(data.message || data.error || 'Request failed')
    }

    return data
  }

  private authHeaders(token: string): HeadersInit {
    return {
      Authorization: `Bearer ${token}`,
    }
  }

  /**
   * Login with email and password
   */
  async login(credentials: LoginCredentials): Promise<AuthSession> {
    const response = await this.request<{ token: string; user: User }>(
      '/auth/login',
      {
        method: 'POST',
        body: JSON.stringify(credentials),
      }
    )

    return {
      user: response.user,
      token: response.token,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days
    }
  }

  /**
   * Register a new user
   */
  async register(credentials: RegisterCredentials): Promise<AuthSession> {
    if (credentials.password !== credentials.passwordConfirm) {
      throw new Error('Passwords do not match')
    }

    const response = await this.request<{ token: string; user: User }>(
      '/auth/register',
      {
        method: 'POST',
        body: JSON.stringify({
          username: credentials.username,
          email: credentials.email,
          password: credentials.password,
        }),
      }
    )

    return {
      user: response.user,
      token: response.token,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    }
  }

  /**
   * Get current user profile
   */
  async getProfile(token: string): Promise<User> {
    return this.request<User>('/auth/profile', {
      method: 'GET',
      headers: this.authHeaders(token),
    })
  }

  /**
   * Update user profile
   */
  async updateProfile(token: string, data: Partial<User>): Promise<User> {
    return this.request<User>('/auth/profile', {
      method: 'PUT',
      headers: this.authHeaders(token),
      body: JSON.stringify(data),
    })
  }

  /**
   * Change password
   */
  async changePassword(
    token: string,
    currentPassword: string,
    newPassword: string
  ): Promise<void> {
    await this.request('/auth/change-password', {
      method: 'PUT',
      headers: this.authHeaders(token),
      body: JSON.stringify({ currentPassword, newPassword }),
    })
  }

  /**
   * Delete account
   */
  async deleteAccount(token: string): Promise<void> {
    await this.request('/auth/account', {
      method: 'DELETE',
      headers: this.authHeaders(token),
    })
  }
}

export const authService = new AuthService(API_BASE_URL)
